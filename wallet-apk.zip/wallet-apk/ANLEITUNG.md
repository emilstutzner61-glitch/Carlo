# Wallet-APK mit GitHub bauen

1. Auf github.com einloggen und ein neues Repository erstellen (z. B. "wallet-apk").
2. ALLE Dateien und Ordner aus diesem Projekt hochladen, inklusive des
   versteckten Ordners ".github" (am PC: "Add file -> Upload files" und den
   Inhalt des entpackten Ordners per Drag & Drop hineinziehen).
3. Oben auf "Actions" gehen. Der Build startet automatisch (oder "APK bauen" ->
   "Run workflow"). Dauert ca. 3-5 Minuten.
4. Fertigen Lauf anklicken, unten bei "Artifacts" die "Wallet-APK" herunterladen
   und entpacken -> app-debug.apk.
5. APK aufs Handy kopieren, antippen und "Installation aus unbekannten Quellen"
   erlauben.

Die Web-App liegt in app/src/main/assets/wallet.html. Wenn du sie änderst und
hochlädst, baut GitHub automatisch eine neue APK.
